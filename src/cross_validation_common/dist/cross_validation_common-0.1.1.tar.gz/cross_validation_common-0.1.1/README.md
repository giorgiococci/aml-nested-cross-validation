# Cross-Validation Common

A library for common cross-validation utilities.

## Library creation script

```sh
cd src/cross-validation-common
python setup.py sdist bdist_wheel
```
